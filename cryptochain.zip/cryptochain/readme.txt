=== Cryptochain ===

Tags: Cryptocurrency, Ethereum
Requires at least: 4.7
Tested up to: 5.8.2
Stable tag: 1.0.1
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Cryptochain allow users to pay for woocommerce orders in cryptocurrency with help of metamask wallet.

== Description ==

Cryptochain is free plugin that allows users to pay in cryptocurrency. Plugin is made on wordpress and only works on woocommerce.Metamask wallet is required for this plugin to function properly. User must have wallet address of metamask and ethereum for payment. 



`<?php code(); ?>`
