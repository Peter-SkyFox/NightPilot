<?php
/**
 * Thankyou page
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/checkout/thankyou.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 3.7.0
 */

defined('ABSPATH') || exit;
?>
<script>
	jQuery(document).ready(function() {
		getValuesInLs();

		function getValuesInLs() {
			order_total = localStorage.getItem("order_total");
			order_fee = localStorage.getItem("order_fee");
			txhash = localStorage.getItem("txHash");
			jQuery(".amount").html(Number(order_total) + Number(order_fee));
			jQuery(".item_amount").html(Number(order_total));
			jQuery(".fee_amount").html(Number(order_fee));
			jQuery("#txid").html(txhash);

		}

	});
</script>

<div class="woocommerce-order">

	<?php
	if ($order) :

		do_action('woocommerce_before_thankyou', $order->get_id());
	?>

		<?php if ($order->has_status('failed')) : ?>

			<p class="woocommerce-notice woocommerce-notice--error woocommerce-thankyou-order-failed"><?php esc_html_e('Unfortunately your order cannot be processed as the originating bank/merchant has declined your transaction. Please attempt your purchase again.', 'woocommerce'); ?></p>

			<p class="woocommerce-notice woocommerce-notice--error woocommerce-thankyou-order-failed-actions">
				<a href="<?php echo esc_url($order->get_checkout_payment_url()); ?>" class="button pay"><?php esc_html_e('Pay', 'woocommerce'); ?></a>
				<?php if (is_user_logged_in()) : ?>
					<a href="<?php echo esc_url(wc_get_page_permalink('myaccount')); ?>" class="button pay"><?php esc_html_e('My account', 'woocommerce'); ?></a>
				<?php endif; ?>
			</p>

		<?php else : ?>

			<p class="woocommerce-notice woocommerce-notice--success woocommerce-thankyou-order-received"><?php echo apply_filters('woocommerce_thankyou_order_received_text', esc_html__('Thank you. Your order has been received.', 'woocommerce'), $order); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped 
																											?></p>

			<ul class="woocommerce-order-overview woocommerce-thankyou-order-details order_details">

				<li class="woocommerce-order-overview__order order">
					<?php esc_html_e('Order number:', 'woocommerce'); ?>
					<strong><?php echo $order->get_order_number(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped 
							?></strong>
				</li>

				<li class="woocommerce-order-overview__date date">
					<?php esc_html_e('Date:', 'woocommerce'); ?>
					<strong><?php echo wc_format_datetime($order->get_date_created()); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped 
							?></strong>
				</li>

				<?php if (is_user_logged_in() && $order->get_user_id() === get_current_user_id() && $order->get_billing_email()) : ?>
					<li class="woocommerce-order-overview__email email">
						<?php esc_html_e('Email:', 'woocommerce'); ?>
						<strong><?php echo $order->get_billing_email(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped 
								?></strong>
					</li>
				<?php endif; ?>

				<li class="woocommerce-order-overview__total ntotal">
					<?php esc_html_e('Total:', 'woocommerce'); ?>
					<strong><?php echo $order->get_formatted_order_total(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped 
							?></strong>
				</li>

				<?php if ($order->get_payment_method_title()) : ?>
					<li class="woocommerce-order-overview__payment-method method">
						<?php esc_html_e('Payment method:', 'woocommerce'); ?>
						<strong><?php echo wp_kses_post($order->get_payment_method_title()); ?></strong>
					</li>
				<?php endif; ?>

			</ul>

		<?php endif; ?>

		<section class="woocommerce-order-details">

			<h2 class="woocommerce-order-details__title">Order details</h2>

			<table class="woocommerce-table woocommerce-table--order-details shop_table order_details">

				<thead>
					<tr>
						<th class="woocommerce-table__product-name product-name">Product</th>
						<th class="woocommerce-table__product-table product-total">Total</th>
					</tr>
				</thead>

				<tbody>
					<?php



					$items = $order->get_items(); ?>

					<?php

					foreach ($items as $item) {

						$product = $item->get_product();
					?>




						<tr class="woocommerce-table__line-item order_item">

							<td class="woocommerce-table__product-name product-name">
								<a href="#" style="color:#FFFFFF;font-size: 17px;"><?php echo $item->get_name(); ?></a> <strong class="product-quantity" style="color:#FFFFFF;font-size: 17px;">×<?php echo esc_html($item->get_quantity()); ?></strong>
							</td>

							<td class="woocommerce-table__product-total product-total">ETH
								<span class="woocommerce-Price-amount item_amount"></span>
							</td>

						</tr>
					<?php }
					?>






				</tbody>


				<tfoot>
					<tr>
						<th scope="row">Transaction Fee</th>
						<td>ETH <span class="woocommerce-Price-amount fee_amount"></span></td>
					</tr>
					<input type="hidden" name="" value="<?php echo esc_attr($order->get_id()); ?>" id="orderid">
					<tr>
						<th scope="row">Payment method</th>
						<td><?php echo  esc_html($order->get_payment_method_title()); ?>

						</td>
					</tr>
					<tr>
						<th scope="row">Transaction Id</th>
						<td id="txid"></td>
					</tr>
					<tr>
						<th scope="row">Total</th>
						<td style="font-size: 17px;color:#FFFFFF">ETH <span class="woocommerce-Price-amount amount"></span></td>
					</tr>
				</tfoot>
			</table>



		</section>



	<?php else : ?>

		<p class="woocommerce-notice woocommerce-notice--success woocommerce-thankyou-order-received"><?php echo apply_filters('woocommerce_thankyou_order_received_text', esc_html__('Thank you. Your order has been received.', 'woocommerce'), null); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped 
		 ?>
		 	
		 </p>

	<?php endif; ?>



</div>

<script type="text/javascript">
	var oid = document.getElementById('orderid').value;
	txhash1 = localStorage.getItem("txHash");

	jQuery.ajax({
		type: 'POST',
		url: ajaxurl,
		data: {
			"action": "cryptupdateorderid",
			"orderid": oid,
			"txhsh": txhash1
		},
		success: function(data) {
			console.log('done');
		}
	});
</script>